﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AttendanceMonitoringSystem
{
    public partial class User_Access : Form
    {
        public User_Access()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            panel2.Enabled = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            panel2.Enabled = false;
        }

        private void User_Access_Load(object sender, EventArgs e)
        {

        }
    }
}
