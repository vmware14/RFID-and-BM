﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AttendanceMonitoringSystem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lbl_school.Text = "Marymount Academy Better Living";
            attendance_grid.Rows.Clear();
            
            
            timer1.Start();
            lbl_date.Text = DateTime.Now.ToLongDateString();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
       
            lbl_time.Text = DateTime.Now.ToLongTimeString();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btn_settings_Click(object sender, EventArgs e)
        {
            Login lg = new Login();
            lg.ShowDialog();
       
 

        }

        private void btn_close_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();

        }
    }
}
