﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AttendanceMonitoringSystem
{
    public partial class server : Form
    {
        public server()
        {
            InitializeComponent();
        }

        private void server_FormClosed(object sender, FormClosedEventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();

        }

        private void registrationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(tp_reg);

           
        }

        private void sMSOneToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SMS sms1 = new SMS();
            sms1.ShowDialog();

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void attendanceInformationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(tp_attendanceInfo);
        }

        private void attendanceParticipantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(tp_attendanceParticipant);
        }

        private void studentListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(tp_studentList);
        }

        private void server_Load(object sender, EventArgs e)
        {

        }

        private void userAccessToolStripMenuItem_Click(object sender, EventArgs e)
        {
            User_Access ua = new User_Access();
            ua.ShowDialog();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            groupBox1.Enabled = true;

        }

        private void button4_Click(object sender, EventArgs e)
        {
            groupBox1.Enabled = false;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            String imageLocation = "";

            try
            {
                OpenFileDialog dialog = new OpenFileDialog();
                dialog.Filter = "jpg files(*.jpg)|*.jpg| PNG files(*.png)|*.png| All Files(*.*)|*.*";

                if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    imageLocation = dialog.FileName;

                    image1.ImageLocation = imageLocation;

                }



            }
            catch(Exception){

                MessageBox.Show("An error occured", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);


            }
        }
    }
}
