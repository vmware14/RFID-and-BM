﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AttendanceMonitoringSystem
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void login_btn_Click(object sender, EventArgs e)
        {

            string user = username_txt.Text;
            string pass = password_txt.Text;

            if ((this.username_txt.Text == "admin") && (this.password_txt.Text == "admin"))
            {

                Form1 f1 = new Form1();
                f1.Hide();
                this.Hide();
                
                server sr = new server();
                MessageBox.Show("Welcome admin... :)", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                sr.ShowDialog();

                

            }
            else
            {
                MessageBox.Show("Username and Password is incorrect","Invalid", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }


        

        }

        private void Login_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Close();
        }

        private void login_btn_Enter(object sender, EventArgs e)
        {

        }

        private void Login_Load(object sender, EventArgs e)
        {
            this.KeyPreview = true;
        }

        private void Login_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                login_btn.PerformClick();
            }
        }
    }
}
